#include "iGraphics.h"

bool jump=false;
int carp_x = 200 , carp_y = 69 , card =1;
int stickp_x = 400, stickp_y = 69;
int coin_x = 600 , coin_y = 80;
int cx = -1, cy= 0;
int stx = -1 , sty = 0;
int cloudx = 700, cloudy = 300;
int cloudxx = -1, cloudyy = 0;
int cloudx1 = 400, cloudy1 = 250;
int cloudxx1 = -1, cloudyy1 = 0;
int Exitx = 700, Exity = 5;
int cactusx =800, cactusy =69;
int cacx=-1,cacy=0;

int gameOver=0;

int onGamePage=1;
int score=0;
char scoreText[100];

int show=1;
void gamepage()
{
//place your drawing codes here
	iClear();
	iShowBMP(0,0,"image\\background.bmp");
	iShowBMP(cloudx,cloudy,"image\\cloud.bmp");
	iShowBMP(cloudx1,cloudy1,"image\\cloud1.bmp");
	if(show==1){
		iShowBMP(coin_x,coin_y,"image\\coin.bmp");
	}
	iShowBMP(stickp_x,stickp_y,"image\\untitled4.bmp");
	iShowBMP(cactusx,cactusy,"image\\untitled5.bmp");
	iShowBMP(carp_x,carp_y,"image\\car.bmp");
	
	iSetColor(255,255,0);
	iShowBMP(0,410,"image\\Score1.bmp");
	_itoa_s(score,scoreText,10);
	iText(90,420,scoreText);
	if(gameOver==1){
		iShowBMP(0,0,"image\\gameover.bmp");
			
		iSetColor(0,175,0);
		iText(450,137,scoreText);
		
	}
	
	
	
		
}

void iDraw()
{
	//place your drawing codes here
	if(onGamePage==1)
		gamepage();
	else if(onGamePage==0){
		gameOver==1;
	}


}

void iMouseMove(int mx, int my)
{
//place your codes here
}

void initializeGame(int speed)
{
	

}

void iMouse(int button, int state, int mx, int my)
{
//place your codes here
	int i;
	for(i=0;i<10;i++){
		if(onGamePage==1 && gameOver==1&& state==GLUT_DOWN && button==GLUT_LEFT_BUTTON && mx >=200&& my>=200 && mx<=370&&my<=250)
		{
			//  initialize the game and start it with maxSpeed = 1 (lowest == easy)
			gameOver=0;
		}
		if(onGamePage==1 && gameOver==1&& state==GLUT_DOWN && button==GLUT_LEFT_BUTTON && mx >=450&& my>=200&&mx<=700&&my<=250)
		{
			exit(0);
		}
	}
}

void iKeyboard(unsigned char key)
{
//place your codes here
	if(key==' '){
		jump=true;
	}
}

void iSpecialKeyboard(unsigned char key)
{
//place your codes for other keys here

	
	if(key == GLUT_KEY_UP){
		jump=true;
	}
	
}
void animate()
{

	if(jump==true && carp_y<=150)
		carp_y++;
	else if(carp_y>=70){
		carp_y--;
		jump=false;
	}
	stickp_x+=stx;
	stickp_y+=sty;
	coin_x+=cx;
	coin_y+=cy;
	cloudx+=cloudxx;
	cloudy+=cloudyy;
	cloudx1+=cloudxx1;
	cloudy1+=cloudyy1;
	cactusx+=cacx;
	cactusy+=cacy;

	if(show==0)
		coin_x=800;
	if(cactusx==70)
		cactusx=800;

	if(cloudx1==0)
		cloudx1=800;
	if(cloudx==0)
		cloudx=800;
	if(stickp_x==20)
		stickp_x=800;
	if(carp_x+64==coin_x && carp_x<=coin_x+20){
		if(carp_x<=coin_x+20)
			show=0;
	}
	if(carp_x+64==stickp_x && carp_y==stickp_y)
	{
		gameOver=1;
	
	}
	else if(carp_x+64==cactusx && carp_y==cactusy)
	{
		gameOver=1;
	}
	
	if(show==0){
		coin_x=700;
		coin_x++;
	}
	if(show==0){
		score+=10;
		show = 1;
	}


}

int main()
{
//place your own initialization codes here.

	iSetTimer(5,animate);
	iInitialize(800, 440,"jumping car");
	return 0;
}